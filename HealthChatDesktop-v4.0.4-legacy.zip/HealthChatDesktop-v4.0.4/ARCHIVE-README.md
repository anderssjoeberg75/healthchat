# HealthChat Desktop v4.0.4 — arkiverad källkod

Det här arkivet innehåller hela skrivbordsversionen av HealthChat exakt som den
såg ut innan projektet skrevs om till en webbapp (commit `1bdacfd`, taggad som
v4.0.4-serien).

Arkivet finns kvar av två skäl:

1. **Historik** – hela Tkinter-gränssnittet, PyInstaller-specen och
   Inno Setup-installern finns här om du någon gång behöver bygga `.exe`-filen igen.
2. **Referens** – webbappen är en portning, inte en nyskrivning. Filerna
   `HealthChatDesktop.py` och `charts_view.py` är originalen som `webapp/backend/`
   och `webapp/frontend/` speglar.

## Bygga den gamla skrivbordsappen igen

```bat
pip install -r requirements.txt
python HealthChatDesktop.py          :: kör från källkod
build.bat                            :: bygg HealthChatDesktop.exe (PyInstaller)
build_installer.bat                  :: bygg HealthChatSetup.exe (Inno Setup)
```

## Vad som lever vidare i webbappen

| Fil i arkivet | Motsvarighet i webbappen |
| --- | --- |
| `HealthChatDesktop.py` (`HealthChatApp`) | `webapp/backend/workspace.py` + routers |
| `HealthChatDesktop.py` (`_process_message`) | `webapp/backend/chatsvc.py` |
| `HealthChatDesktop.py` (dialoger) | modaler i `webapp/frontend/static/app.js` |
| `charts_view.py` (matplotlib-figurer) | `webapp/backend/charts.py` |
| `charts_view.py` (kort & tabell) | `webapp/backend/metrics.py` |
| `ai_client.py`, `garmin_*.py`, `*_handler.py`, `calorie_calc.py` | oförändrade i repo-roten, återanvänds av webbappen |

Skrivbordsversionens data låg i `~/.healthchat/`. Webbappen lagrar motsvarande
data per användare under serverns datakatalog (`HEALTHCHAT_DATA_DIR`).
